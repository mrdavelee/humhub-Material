<?php
    echo $calendarEntry->getWallOut();
?>