<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Yakındaki</strong> etkinlikler',
);
