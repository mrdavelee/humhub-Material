<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% hat für »%contentTitle%« zugesagt.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% nimmt vielleicht bei »%contentTitle%« teil.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nimmt nicht bei »%contentTitle%« teil.',
);
