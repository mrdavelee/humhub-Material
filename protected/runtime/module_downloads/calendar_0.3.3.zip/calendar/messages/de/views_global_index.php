<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Termine</strong> filtern',
  '<strong>Select</strong> calendars' => '<strong>Kalender</strong> auswählen',
  'Already responded' => 'Beantwortet',
  'Followed spaces' => 'Folgende Spaces',
  'Followed users' => 'Folgende Benutzer',
  'I´m attending' => 'Ich nehme teil',
  'My events' => 'Meine Termine',
  'My profile' => 'Aus meinem Profil',
  'My spaces' => 'Aus meinen Spaces',
  'Not responded yet' => 'Nicht beantwortet',
);
