<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtra</strong> esdeveniments',
  '<strong>Select</strong> calendars' => '<strong>seleccinoa</strong> calendaris',
  'Already responded' => 'Ja has respost',
  'Followed spaces' => 'Espais on participes',
  'Followed users' => 'Membres a qui segueixes',
  'I´m attending' => 'Hi aniré',
  'My events' => 'Els meus esdeveniments',
  'My profile' => 'El meu perfil',
  'My spaces' => 'Els meus espais',
  'Not responded yet' => 'No has respòs encara',
);
