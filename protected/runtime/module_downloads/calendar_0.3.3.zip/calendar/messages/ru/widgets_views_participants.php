<?php
return array (
  ':count attending' => ':человек посетит',
  ':count declined' => ':отказалось посетить',
  ':count maybe' => ':возможно посетят',
  'Participants:' => 'Участники:',
);
