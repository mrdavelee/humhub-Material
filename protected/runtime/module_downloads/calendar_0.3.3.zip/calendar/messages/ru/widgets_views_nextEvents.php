<?php
return array (
  '<strong>Upcoming</strong> events ' => 'Будущие события',
);
