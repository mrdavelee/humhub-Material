<?php
return array (
  '<strong>Filter</strong> events' => '<strong>フィルタ</strong> イベントをフィルタ',
  '<strong>Select</strong> calendars' => '<strong>選択</strong> カレンダーを選択',
  'Already responded' => '回答済み',
  'Followed spaces' => 'スペースをフォローする',
  'Followed users' => 'ユーザーをフォローする',
  'I´m attending' => '参加する',
  'My events' => '自分のイベント',
  'My profile' => '私のプロフィール',
  'My spaces' => 'マイスペース',
  'Not responded yet' => '未回答',
);
