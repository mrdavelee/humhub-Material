<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% criar uma nova %contentTitle%',
);
