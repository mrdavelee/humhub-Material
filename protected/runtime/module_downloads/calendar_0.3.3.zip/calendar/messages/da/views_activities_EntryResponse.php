<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% deltager til %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% deltager måske til %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% deltager ikke til %contentTitle%.',
);
