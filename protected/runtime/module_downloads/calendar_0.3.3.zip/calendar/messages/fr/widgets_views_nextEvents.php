<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Prochains</strong> événements ',
);
