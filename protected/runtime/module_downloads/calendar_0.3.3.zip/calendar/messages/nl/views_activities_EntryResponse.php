<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% neemt deel aan %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% neemt misschien deel aan %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% neemt niet deel aan %contentTitle%.',
);
