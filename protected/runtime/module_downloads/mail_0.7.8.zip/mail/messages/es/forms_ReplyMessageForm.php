<?php
return array (
  'Message' => 'Mensaje',
);
