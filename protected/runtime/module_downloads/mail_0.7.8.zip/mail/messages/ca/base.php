<?php
return array (
  'Messages' => 'Missatges',
);
