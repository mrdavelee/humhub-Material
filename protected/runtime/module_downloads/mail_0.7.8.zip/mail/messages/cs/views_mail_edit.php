<?php
return array (
  'Edit message entry' => 'Změnit obsah zprávy',
  'Save' => 'Uložit',
);
