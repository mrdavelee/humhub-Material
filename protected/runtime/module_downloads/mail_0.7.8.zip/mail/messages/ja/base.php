<?php
return array (
  'Messages' => 'メッセージ',
);
