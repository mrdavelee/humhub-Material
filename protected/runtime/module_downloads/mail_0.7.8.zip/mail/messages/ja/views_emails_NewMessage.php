<?php
return array (
  '<strong>New</strong> message' => '<strong>New</strong> メッセージ',
  'Reply now' => '返信',
  'sent you a new message:' => 'あなたに新しいメッセージを送信します：',
);
