<?php
return array (
  'Inbox' => 'Posteingang',
  'New' => 'Neu',
  'New message' => 'Neue Nachricht',
  'There are no messages yet.' => 'Es sind keine Nachrichten vorhanden.',
);
