<?php
return array (
  'You cannot send a email to yourself!' => 'Du kannst dir selber keine Mail senden!',
);
