<?php
return array (
  '<strong>Most</strong> active people' => 'Les membres les <strong>plus</strong> actifs',
  'Comments created' => 'Commentaire(s)',
  'Likes given' => 'Mention(s) "J\'aime"',
  'Posts created' => 'Publication(s)',
);
