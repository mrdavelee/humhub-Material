<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Aktyviausi</strong> žmonės',
  'Comments created' => 'Sukurti komentarai',
  'Likes given' => 'Pamėgti',
  'Posts created' => 'Sukurti skelbimai',
);
