<?php
return array (
  '<strong>Most</strong> active people' => '',
  'Comments created' => 'Yorumlar',
  'Likes given' => 'Beğeniler',
  'Posts created' => 'Mesajlar',
);
