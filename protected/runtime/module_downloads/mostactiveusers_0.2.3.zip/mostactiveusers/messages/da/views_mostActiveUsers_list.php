<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Mest</strong> aktive personer',
  'Comments created' => 'Kommentarer oprettet',
  'Likes given' => 'Syntes godt om givet',
  'Posts created' => 'Opslag oprettet',
);
