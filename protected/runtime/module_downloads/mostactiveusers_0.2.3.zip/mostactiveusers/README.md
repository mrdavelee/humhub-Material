## Most-Active-Users

Adds a panel on the Dashboard, indicating the most active users.

__Author:__ Marjana Pesic  