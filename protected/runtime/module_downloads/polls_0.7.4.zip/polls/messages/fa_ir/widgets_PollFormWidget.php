<?php
return array (
  'Ask' => 'بپرس',
);
