<?php
return array (
  'Reset my vote' => 'Reset mijn antwoord',
  'Vote' => 'Stem',
  'and {count} more vote for this.' => 'en {count} anderen hebben voor dit gestemd.',
  'votes' => 'stemmen',
);
