<?php
return array (
  'Allow multiple answers per user?' => 'Meerdere antwoorden per gebruiker toelaten?',
  'Ask something...' => 'Stel je vraag...',
  'Possible answers (one per line)' => 'Mogelijke antwoorden (1 per lijn)',
);
