<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} heeft een nieuwe poll aangemaakt en jou aangewezen.',
);
