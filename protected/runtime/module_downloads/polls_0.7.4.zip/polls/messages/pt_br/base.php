<?php
return array (
  'Polls' => 'Enquete',
);
