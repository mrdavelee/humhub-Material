<?php
return array (
  'Allow multiple answers per user?' => 'Permitir várias respostas por usuário?',
  'Ask something...' => 'Pergunte alguma coisa...',
  'Possible answers (one per line)' => 'Possíveis respostas (um por linha)',
);
