<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} ha creato un nuovo sondaggio e l\'ha assegnato a te.',
);
