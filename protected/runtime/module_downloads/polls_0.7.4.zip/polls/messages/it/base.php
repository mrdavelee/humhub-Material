<?php
return array (
  'Polls' => 'Sondaggi',
);
