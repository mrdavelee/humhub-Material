<?php
return array (
  'Answers' => 'Réponses',
  'Multiple answers per user' => 'Réponses multiples par utilisateur',
  'Please specify at least {min} answers!' => 'Attention, vous devrez spécifier {min} réponses minimum.',
  'Question' => 'Question',
);
