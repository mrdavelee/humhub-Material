<?php
return array (
  'Allow multiple answers per user?' => 'Autoriser les réponses multiples ?',
  'Ask something...' => 'Votre question...',
  'Possible answers (one per line)' => 'Réponses possibles (1 par ligne)',
);
