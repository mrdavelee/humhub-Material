<?php
return array (
  'Reset my vote' => 'Annuler mon vote',
  'Vote' => 'Voter',
  'and {count} more vote for this.' => 'et {count} réponses en plus.',
  'votes' => 'réponses',
);
