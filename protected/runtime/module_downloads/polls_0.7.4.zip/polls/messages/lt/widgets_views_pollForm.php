<?php
return array (
  'Allow multiple answers per user?' => 'Ar leisti vienam vartotojui pasirinkti daugiau nei vieną atsakymo variantą?',
  'Ask something...' => 'Paklausk ko nors...',
  'Possible answers (one per line)' => 'Galimi atsakymai (po vieną)',
);
