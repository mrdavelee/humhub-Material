<?php
return array (
  'Reset my vote' => '',
  'Vote' => '',
  'and {count} more vote for this.' => '',
  'votes' => '',
);
