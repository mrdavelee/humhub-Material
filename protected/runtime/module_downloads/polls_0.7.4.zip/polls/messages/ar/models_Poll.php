<?php
return array (
  'Answers' => '',
  'Multiple answers per user' => '',
  'Please specify at least {min} answers!' => '',
  'Question' => '',
);
