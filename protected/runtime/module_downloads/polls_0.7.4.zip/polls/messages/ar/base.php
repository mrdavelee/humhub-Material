<?php
return array (
  'Polls' => '',
);
