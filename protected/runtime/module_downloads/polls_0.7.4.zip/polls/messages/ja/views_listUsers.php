<?php
return array (
  'User who vote this' => 'これに投票するユーザー',
);
