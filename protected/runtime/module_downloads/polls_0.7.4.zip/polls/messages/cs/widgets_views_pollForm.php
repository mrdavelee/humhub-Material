<?php
return array (
  'Allow multiple answers per user?' => 'Povolit více odpovědí od jednoho uživatele?',
  'Ask something...' => 'Položte otázku...',
  'Possible answers (one per line)' => 'Možné odpovědi (oddělte novým řádkem)',
);
