<?php
return array (
  'Allow multiple answers per user?' => 'Sind Mehrfachantworten zugelassen?',
  'Ask something...' => 'Stelle eine Frage...',
  'Possible answers (one per line)' => 'Mögliche Antworten (Eine pro Zeile)',
);
