<?php
return array (
  'Could not load poll!' => 'Konnte Umfrage nicht laden!',
  'Invalid answer!' => 'Unzulässige Antwort!',
  'Users voted for: <strong>{answer}</strong>' => 'Benutzer stimmten für: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Mehrfachantworten sind nicht zugelassen!',
  'You have insufficient permissions to perform that operation!' => 'Es fehlen die nötigen Rechte, um die Anfrage zu bearbeiten!',
);
