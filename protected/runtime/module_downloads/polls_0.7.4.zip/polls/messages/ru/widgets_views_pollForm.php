<?php
return array (
  'Allow multiple answers per user?' => 'Разрешить несколько варинатов ответов пользователю?',
  'Ask something...' => 'Спросить как нибудь...',
  'Possible answers (one per line)' => 'Варианты ответов (по одному в каждой строке) ',
);
