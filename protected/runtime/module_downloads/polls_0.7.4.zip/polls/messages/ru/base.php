<?php
return array (
  'Polls' => 'Опросы',
);
