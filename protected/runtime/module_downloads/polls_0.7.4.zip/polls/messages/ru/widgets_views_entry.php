<?php
return array (
  'Reset my vote' => 'Отозвать мой голос',
  'Vote' => 'Голосование',
  'and {count} more vote for this.' => 'еще {count} человек проголосовало.',
  'votes' => 'голосов',
);
