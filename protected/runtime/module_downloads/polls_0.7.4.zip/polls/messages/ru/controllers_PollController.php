<?php
return array (
  'Could not load poll!' => 'Не удалось загрузить опрос!',
  'Invalid answer!' => 'Неверный ответ!',
  'Users voted for: <strong>{answer}</strong>' => 'Пользователи проголосовали за: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Голосование за несколько вариантов отключено!',
  'You have insufficient permissions to perform that operation!' => 'Вы должны иметь доступ на выполнение этой операции!',
);
