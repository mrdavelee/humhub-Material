<?php
return array (
  'User who vote this' => 'Hangi kullanıcılar oyladı',
);
