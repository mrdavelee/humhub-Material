<?php
return array (
  'Answers' => 'Respostes',
  'Multiple answers per user' => 'Es permeten múltiples respostes',
  'Please specify at least {min} answers!' => 'Si us plau especifica com a mínim {min} respostes!',
  'Question' => 'Pregunta',
);
