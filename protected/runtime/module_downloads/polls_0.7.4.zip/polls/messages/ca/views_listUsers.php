<?php
return array (
  'User who vote this' => 'Membres que han votat això',
);
