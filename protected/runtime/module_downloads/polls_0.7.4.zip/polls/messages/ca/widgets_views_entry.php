<?php
return array (
  'Reset my vote' => 'Restableix el meu vot',
  'Vote' => 'Vot',
  'and {count} more vote for this.' => 'i {count} més han votat això.',
  'votes' => 'vots',
);
