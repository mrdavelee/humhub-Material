<?php
return array (
  'Allow multiple answers per user?' => 'Vols permetre múltiples respostes?',
  'Ask something...' => 'Pregunta alguna cosa...',
  'Possible answers (one per line)' => 'Respostes (una per línia)',
);
