<?php
return array (
  'Allow multiple answers per user?' => 'Zezwól na wielokrotne odpowiedzi na użytkownika? ',
  'Ask something...' => 'Zapytaj o coś...',
  'Possible answers (one per line)' => 'Możliwe odpowiedzi (jedna na linię)',
);
