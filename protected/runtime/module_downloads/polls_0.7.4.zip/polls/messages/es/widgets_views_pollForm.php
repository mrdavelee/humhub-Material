<?php
return array (
  'Allow multiple answers per user?' => '¿Permitir multiples respuestas por usuario?',
  'Ask something...' => 'Pregunta algo...',
  'Possible answers (one per line)' => 'Posibles respuestas (una por línea)',
);
