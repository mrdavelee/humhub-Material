<?php
return array (
  'Add more participants to your conversation...' => 'Pridėti daugiau dalyvių į pokalbį...',
  'Close' => 'Uždaryti',
  'Send' => 'Išsiųsti',
);
