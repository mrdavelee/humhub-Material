<?php
return array (
  '<strong>New</strong> message' => '<strong>Neue</strong> Nachricht',
  'Reply now' => 'Antworte jetzt',
  'sent you a new message:' => 'sendete dir eine neue Nachricht:',
);
