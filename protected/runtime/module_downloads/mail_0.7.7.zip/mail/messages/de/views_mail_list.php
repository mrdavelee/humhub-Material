<?php
return array (
  'There are no messages yet.' => 'Aktuell keine Nachrichten vorhanden.',
);
