<?php
return array (
  'New message' => 'Nuevo mensaje',
  'Send message' => 'Enviar mensaje',
);
