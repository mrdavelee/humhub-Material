<?php
return array (
  'New message in discussion from %displayName%' => 'Ny besked i diskussionen fra %displayName%',
);
