<?php
return array (
  'Messages' => 'Zprávy',
);
