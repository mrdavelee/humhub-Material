<?php
return array (
  'Groups' => 'Gruppi',
  'Members' => 'Membri',
  'Spaces' => 'Space',
  'User Posts' => 'Messaggi utente',
);
