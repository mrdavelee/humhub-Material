<?php
return array (
  'Messages' => 'Messages',
  'New message' => 'Nouveau message',
  'Show all messages' => 'Montrer tous les messages',
);
