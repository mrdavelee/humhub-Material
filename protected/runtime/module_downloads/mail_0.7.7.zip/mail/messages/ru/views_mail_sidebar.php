<?php
return array (
  'Groups' => 'Группы',
  'Members' => 'Участники',
  'Spaces' => 'Пространства',
  'User Posts' => 'Сообщения пользователей',
);
