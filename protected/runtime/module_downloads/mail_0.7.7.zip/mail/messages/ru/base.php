<?php
return array (
  'Messages' => 'Сообщения',
);
